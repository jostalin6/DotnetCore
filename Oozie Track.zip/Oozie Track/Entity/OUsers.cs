﻿using OozieJobs.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace OozieJobs.Entity
{
   
    public class O_Users
    {
        [Key]
        public int USID { get; set; }
        public string Password { get; set; }

        public string Userid { get; set; }
    }

    public class Register : OUsersDetails
    {
        public string Token { get; set; }
        public string Password { get; set; }

    }
    public class Forgot
    {
        public string Emailid { get; set; }

    }
}
