﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using OozieJobs;
using OozieJobs.Entity;
using OozieJobs.Models;
using OozieJobs.Responses;
//new branch

namespace Oozie_Track.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        
       
        private IUserService _userService;
        public UserController(
         IUserService userService)
        {
            _userService = userService;
        }
        // GET api/values
        [HttpGet("KeepAlive")]
        [AllowAnonymous]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpPost("user")]
        [AllowAnonymous]
        public GlobalResponses user([FromBody] O_Users user)
        {
            GlobalResponses globalResponses = new GlobalResponses();

            var dbuser = _userService.Authenticate(user);


            if (dbuser != 0)
            {
                globalResponses.statuscode = 100;
                globalResponses.statusmessage = "Success";
                return globalResponses;
            }
            else
            {
                globalResponses.statuscode = 101;
                globalResponses.statusmessage = "Not found!";
                return globalResponses;
            }
        }

        [HttpPost("register")]
        public GlobalResponses register([FromBody] Register user)
        {
            GlobalResponses globalResponses = new GlobalResponses();

            var dbuser = _userService.Register(user);
            //var dbuser= 1;
            if (dbuser != 0)
            {
                globalResponses.statuscode = 102;
                globalResponses.statusmessage = "Success";
                return globalResponses;
            }
            else
            {
                globalResponses.statuscode = 103;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        [HttpPost("forgot")]
        public GlobalResponses forgot([FromBody] Forgot user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            //var dbuser = _userService.Forgot(user);
           var dbuser = 1;
            if (dbuser != 0)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return globalResponses;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        
        [HttpPost("getcustomer")]
        public dynamic getcustomer([FromBody] Getcustomer user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            var dbuser = _userService.getcustomer(user);

            //var dbuser= 1;
            if (dbuser != null)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return dbuser;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        [HttpPost("searchcustomer")]
        public dynamic searchcustomer([FromBody] Searchparams user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            var dbuser = _userService.searchcustomer(user);
            Console.Write(dbuser);
            //var dbuser= 1;
            if (dbuser != null)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return dbuser;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        [HttpPost("schedule")]
        public dynamic schedule([FromBody] schedule user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            var dbuser = _userService.schedule(user);

            if (dbuser == 1)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return globalResponses;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        [HttpPost("getitem")]
        public dynamic getitem([FromBody] getitem user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            var dbuser = _userService.getitem(user);

            if (dbuser != null)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return dbuser;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }

        [HttpPost("updatecustomer")]
        public dynamic updatecustomer([FromBody] schedule user)
        {
            GlobalResponses globalResponses = new GlobalResponses();


            var dbuser = _userService.updatecustomer(user);

            if (dbuser == 1)
            {
                globalResponses.statuscode = 104;
                globalResponses.statusmessage = "Success";
                return globalResponses;
            }
            else
            {
                globalResponses.statuscode = 105;
                globalResponses.statusmessage = "User Not Registered!";
                return globalResponses;
            }
        }
    }
}
