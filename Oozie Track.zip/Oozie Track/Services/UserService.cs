﻿using OozieJobs.Entity;
using OozieJobs.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;

namespace OozieJobs
{
    public interface IUserService
    {
        int Authenticate(O_Users user);
        int Register(Register user);

       // int Forgot(Forgot forgot);

        dynamic getcustomer(Getcustomer getcustomer);

        dynamic searchcustomer(Searchparams searchparams);

        dynamic schedule(schedule schedule);

        dynamic getitem(getitem getitem);

        dynamic updatecustomer(schedule schedule);
        
    }
    public class UserService : IUserService
    {
        int auth;

        private ooziejobsContext _context;
        public UserService(ooziejobsContext context)
        {
            _context = context;
        }

        public int Authenticate(O_Users user)
        {
            if (string.IsNullOrEmpty(user.Password))
                return 0;

            var users = _context.O_Users.SingleOrDefault(x => x.Userid == user.Userid && x.Password == user.Password);

            //check if username exists
            if (users != null)
            {
                auth = users.Usid;
                return 1;
            }
            else
            {
                auth = 0;
                return 0;
            }
            //authentication successful

        }

        public int Register(Register user)
        {
            if (string.IsNullOrEmpty(user.Password))
                return 0;
            Console.Write(user);

            OUsers OUsers = new OUsers
            {
                Password = user.Password,
                Userid = user.Userid,
                Token = user.Token
            };

            OUsersDetails oUsersDetails = new OUsersDetails
            {
                FirstName = user.FirstName,
                LastName = "",
                Passcode = user.Passcode,
                City = user.City,
                Active = true,
                Type = "",
                Userid = user.Userid,
                Mobile = user.Mobile

            };

            _context.O_Users.Add(OUsers);
            _context.O_UsersDetails.Add(oUsersDetails);

            _context.SaveChanges();

            return 1;
        }
   
        public dynamic getcustomer(Getcustomer getcustomer)
        {
            var users = _context.O_Users.SingleOrDefault(x => x.Userid == getcustomer.userid);
            try
            {
                var query = (from c in _context.OCustomerDetails
                             where c.Usid == users.Usid
                             select c);

                var limitdata = query.Take(getcustomer.limit);


                return limitdata.ToList();

            }
            catch
            {
                return null;
            }

        }

        public dynamic searchcustomer(Searchparams searchparams)
        {

            try
            {

                if (searchparams.searchparam != null || searchparams.searchparam != "")
                {
                    var query = _context.OCustomerDetails.Where(t => t.Userid == searchparams.id && t.CustomerName.Contains(searchparams.searchparam)
                || t.CustomerEmail.Contains(searchparams.searchparam)
                ).OrderBy(t => t.ScheduleDateTime);

                    return query.ToList();
                }
                else
                {
                    var query = _context.OCustomerDetails.Where(t => t.Userid == searchparams.id).OrderBy(t => t.ScheduleDateTime);
                    return query.ToList();
                }
            }
            catch
            {
                return null;
            }

        }
        public dynamic schedule(schedule schedule)
        {

            try
            {
                if (schedule.Status == true)
                    schedule.Status = true;
                else
                    schedule.Status = false;

                var user = _context.O_Users.SingleOrDefault(x => x.Userid == schedule.Userid);

                OCustomerDetails oUsers = new OCustomerDetails
                {
                    CustomerName = schedule.Customername,
                    CustomerEmail = schedule.Emailid,
                    Mobile = schedule.Mobile,
                    Address = schedule.Address,
                    Comments = schedule.Comments,
                    ScheduleDateTime = schedule.Scheduletime,
                    Active = schedule.Status,
                    Trigger = true,
                    Userid = user.Usid
                };
                _context.OCustomerDetails.Add(oUsers);
                _context.SaveChanges();
                return 1;
            }
            catch
            {
                return null;
            }

        }

        public dynamic getitem(getitem getitem)
        {

            try
            {
                var user = _context.OCustomerDetails.SingleOrDefault(x => x.Usid == getitem.customerid && x.Userid == getitem.userid);

                return user;
            }
            catch
            {
                return null;
            }

        }

        public dynamic updatecustomer(schedule schedule)
        {

            try
            {
                var customer = _context.OCustomerDetails.SingleOrDefault(x => x.Usid == schedule.uid);

                if (customer != null)
                {
                    customer.Mobile = schedule.Mobile;
                    customer.CustomerEmail = schedule.Emailid;
                    customer.Address = schedule.Address;
                    customer.Comments = schedule.Comments;
                    customer.ScheduleDateTime = schedule.Scheduletime;
                    customer.Active = schedule.Status;
                    _context.SaveChanges();
                    return 1;
                }
                return 1;
            }
            catch
            {
                return null;
            }
        }

        public int Forget(Forgot forgot)
        {
            return 1;
        }
    }
}

