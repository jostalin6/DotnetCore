﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OozieJobs.Models
{
    public class OCustomerDetails
    {
        public int Usid { get; set; }
        public string CustomerName { get; set; }
        public string Mobile { get; set; }

        public string Address { get; set; }
        public string CustomerEmail { get; set; }
        public string Comments { get; set; }
        public DateTime? ScheduleDateTime { get; set; }
        public bool? Active { get; set; }
        public int Userid { get; set; }
        public bool? Trigger { get; set; }
    }
}
