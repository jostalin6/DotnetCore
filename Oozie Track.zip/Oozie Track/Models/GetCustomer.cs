﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OozieJobs.Models
{
    public class Getcustomer
    {
        public string userid { get; set; }
        public int limit { get; set; }
    }

    public class Customerlist
    {
        public int id { get; set; }
        public string customername { get; set; }
    }

    public class Searchparams
    {
        public int id { get; set; }
        public string searchparam { get; set; }

    }

    public class schedule
    {
        public int uid { get; set; }
        public string Customername { get; set; }
        public string Mobile { get; set; }

        public string Address { get; set; }

        public string Comments { get; set; }

        public DateTime? Scheduletime { get; set; }

        public bool Status { get; set; }

        public string Emailid { get; set; }

        public string Userid { get; set; }
    }
    public class getitem
    {
        public int userid { get; set; }
        public int customerid { get; set; }
    }

}
