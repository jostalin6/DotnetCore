﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace OozieJobs.Models
{
    public partial class ooziejobsContext : DbContext
    {
        public ooziejobsContext()
        {
        }

        public ooziejobsContext(DbContextOptions<ooziejobsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<OUsers> O_Users { get; set; }
        public virtual DbSet<OUsersDetails> O_UsersDetails { get; set; }

        public virtual DbSet<OCustomerDetails> OCustomerDetails { get; set; }

        // Unable to generate entity type for table 'dbo.O_CustomerDetails'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Recommented_Jobs'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Upcomming_Events'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Free_Course'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Latest_Job'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Prefered_Job_Master'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.O_Prefered_Location_Master'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=LENOVO-PC;Database=ooziejobs;user=ooziejobs;password=ooziejobs123;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OUsers>(entity =>
            {
                entity.HasKey(e => e.Usid);

                entity.ToTable("O_Users");

                entity.Property(e => e.Usid).HasColumnName("USID");

                entity.Property(e => e.Password).HasMaxLength(20);

                entity.Property(e => e.Userid).HasMaxLength(30);
            });

            modelBuilder.Entity<OUsersDetails>(entity =>
            {
                entity.ToTable("O_Users_Details");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Address)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.City)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Mobile)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ScheduleDatetime).HasColumnType("datetime");

                entity.Property(e => e.Type)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Userid).HasMaxLength(30);
            });
        }
    }
}
