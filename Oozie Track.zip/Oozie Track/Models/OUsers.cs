﻿using System;
using System.Collections.Generic;

namespace OozieJobs.Models
{
    public partial class OUsers
    {
        public int Usid { get; set; }
        public string Password { get; set; }
        public string Userid { get; set; }
        public string Token { get; set; }
    }
}
