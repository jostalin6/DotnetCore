﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OozieJobs.Responses
{
    public class GlobalResponses
    {
        public int statuscode { get; set; }
        public string statusmessage { get; set; }
    }
}
